<?php
namespace App\Services;

use App\Models\User;
use App\Repositories\UserRepository;

class ProfileService
{
    private UserRepository $users;

    public function __construct(UserRepository $users)
    {
        $this->users = $users;
    }

    public function getProfile(User $user): array
    {
        return $user->toPublicArray();
    }

    public function updateProfile(User $user, array $data): array
    {
        $user->fullName = $data['full_name'] ?? $user->fullName;
        $user->description = $data['description'] ?? $user->description;
        $user->avatarUrl = $data['avatar_url'] ?? $user->avatarUrl;
        $user->avatarFrame = $data['avatar_frame'] ?? $user->avatarFrame;
        if (array_key_exists('avatar_sticker', $data)) {
            $user->avatarSticker = $data['avatar_sticker'] ?: null;
        }
        $user->statusNote = $data['status_note'] ?? $user->statusNote;
        if (array_key_exists('status_note_expires', $data)) {
            $raw = $data['status_note_expires'];
            if (is_string($raw) && $raw !== '') {
                $ts = strtotime($raw);
                $user->statusNoteExpires = $ts ? date('Y-m-d H:i:s', $ts) : $raw;
            } else {
                $user->statusNoteExpires = null;
            }
        }
        if (array_key_exists('status_note_color', $data)) {
            $user->statusNoteColor = $data['status_note_color'];
        }
        if (array_key_exists('status_note_bg', $data)) {
            $user->statusNoteBg = $data['status_note_bg'];
        }
        if (array_key_exists('status_note_emoji', $data)) {
            $user->statusNoteEmoji = $data['status_note_emoji'];
        }
        $user->socialFacebook = $data['social_facebook'] ?? $user->socialFacebook;
        $user->socialInstagram = $data['social_instagram'] ?? $user->socialInstagram;
        $user->socialTiktok = $data['social_tiktok'] ?? $user->socialTiktok;
        $user->socialYoutube = $data['social_youtube'] ?? $user->socialYoutube;

        // Personalization
        if (array_key_exists('theme_mode', $data)) $user->themeMode = $data['theme_mode'] ?: null;
        if (array_key_exists('accent_color', $data)) $user->accentColor = $data['accent_color'] ?: null;
        if (array_key_exists('link_color', $data)) $user->linkColor = $data['link_color'] ?: null;
        if (array_key_exists('language', $data)) $user->language = $data['language'] ?: null;
        if (array_key_exists('timezone', $data)) $user->timezone = $data['timezone'] ?: null;
        if (array_key_exists('pronouns', $data)) $user->pronouns = $data['pronouns'] ?: null;
        if (array_key_exists('website_url', $data)) $user->websiteUrl = $data['website_url'] ?: null;
        if (array_key_exists('location', $data)) $user->location = $data['location'] ?: null;
        if (array_key_exists('birthdate', $data)) $user->birthdate = $data['birthdate'] ?: null;
        if (array_key_exists('birthdate_visibility', $data)) $user->birthdateVisibility = $data['birthdate_visibility'] ?: null;
        if (array_key_exists('text_scale', $data)) $user->textScale = $data['text_scale'] ?: null;
        if (array_key_exists('compact_mode', $data)) $user->compactMode = (int)!!$data['compact_mode'];
        if (array_key_exists('reduce_motion', $data)) $user->reduceMotion = (int)!!$data['reduce_motion'];
        if (array_key_exists('halo_strength', $data)) {
            $val = $data['halo_strength'];
            $user->haloStrength = ($val === null || $val === '') ? null : $val;
        }
        if (array_key_exists('avatar_frame_favs', $data)) $user->avatarFrameFavs = $data['avatar_frame_favs'] ?: null;

        $this->users->updateProfile($user);
        return $user->toPublicArray();
    }
}
