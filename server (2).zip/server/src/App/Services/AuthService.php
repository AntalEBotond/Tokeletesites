<?php
namespace App\Services;

use App\Repositories\UserRepository;
use App\Repositories\TokenRepository;
use App\Models\User;

class AuthService
{
    private UserRepository $users;
    private TokenRepository $tokens;
    private int $tokenTtl;

    public function __construct(UserRepository $users, TokenRepository $tokens, int $tokenTtl)
    {
        $this->users = $users;
        $this->tokens = $tokens;
        $this->tokenTtl = $tokenTtl;
    }

    public function register(string $username, string $password, ?string $fullName = null, ?string $email = null): User
    {
        return $this->users->create($username, $password, $fullName, $email);
    }

    public function login(string $username, string $password): ?array
    {
        $user = $this->users->findByUsername($username);
        if (!$user) {
            return null;
        }
        if (!password_verify($password, $user->passwordHash)) {
            return null;
        }
        $rawToken = bin2hex(random_bytes(32));
        $token = $this->tokens->create($user->id, $rawToken, $this->tokenTtl);
        return ['token' => $token, 'user' => $user];
    }

    public function authenticate(string $authHeader): ?User
    {
        if (!preg_match('/Bearer\s+(\S+)/i', $authHeader, $m)) {
            return null;
        }
        $rawToken = $m[1];
        $userId = $this->tokens->findUserIdByToken($rawToken);
        if (!$userId) {
            return null;
        }
        return $this->users->findById($userId);
    }
}

