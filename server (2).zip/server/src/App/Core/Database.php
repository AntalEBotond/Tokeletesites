<?php
namespace App\Core;

use PDO;
use PDOException;

class Database
{
    private static ?PDO $pdo = null;
    private static array $config;

    public static function init(array $config): void
    {
        self::$config = $config;
    }

    public static function pdo(): PDO
    {
        if (self::$pdo) {
            return self::$pdo;
        }
        $db = self::$config['db'] ?? [];
        $host = $db['host'] ?? '127.0.0.1';
        $port = $db['port'] ?? '3306';
        $name = $db['name'] ?? 'bot_app';
        $charset = $db['charset'] ?? 'utf8mb4';
        $user = $db['user'] ?? 'root';
        $pass = $db['pass'] ?? '';

        $dsn = "mysql:host={$host};port={$port};dbname={$name};charset={$charset}";
        $opts = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ];

        try {
            self::$pdo = new PDO($dsn, $user, $pass, $opts);
        } catch (PDOException $e) {
            // In production, do not expose $e->getMessage()
            http_response_code(500);
            header('Content-Type: application/json');
            echo json_encode(['error' => 'Database connection failed']);
            exit;
        }
        return self::$pdo;
    }
}

