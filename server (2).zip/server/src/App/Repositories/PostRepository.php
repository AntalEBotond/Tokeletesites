<?php
namespace App\Repositories;

use App\Core\Database;
use App\Models\Post;
use PDO;

class PostRepository
{
    private PDO $pdo;

    public function __construct()
    {
        $this->pdo = Database::pdo();
    }

    public function create(int $userId, string $content, ?string $imageUrl = null, string $visibility = 'public', ?string $bg = null, ?string $fg = null, ?string $emoji = null): Post
    {
        $stmt = $this->pdo->prepare('INSERT INTO posts (user_id, content, image_url, visibility, bg_color, text_color, feeling_emoji) VALUES (?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([$userId, $content, $imageUrl, $visibility, $bg, $fg, $emoji]);
        $id = (int)$this->pdo->lastInsertId();
        return $this->findById($id);
    }

    public function findById(int $id): ?Post
    {
        $sql = 'SELECT p.*, u.full_name AS user_name, u.avatar_url AS user_avatar
                FROM posts p
                JOIN `user` u ON u.id = p.user_id
                WHERE p.id = ?';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ? Post::fromArray($row) : null;
    }

    public function latest(int $limit = 20, int $offset = 0): array
    {
        $limit = max(1, min(100, $limit));
        $offset = max(0, $offset);
        $sql = 'SELECT p.*, u.full_name AS user_name, u.avatar_url AS user_avatar
                FROM posts p
                JOIN `user` u ON u.id = p.user_id
                ORDER BY p.id DESC
                LIMIT :limit OFFSET :offset';
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        $rows = $stmt->fetchAll();
        return array_map(fn($r) => Post::fromArray($r)->toArray(), $rows ?: []);
    }
}
