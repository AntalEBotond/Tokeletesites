<?php
namespace App\Repositories;

use App\Core\Database;
use App\Models\User;
use PDO;

class UserRepository
{
    private PDO $pdo;

    public function __construct()
    {
        $this->pdo = Database::pdo();
    }

    public function findById(int $id): ?User
    {
        $stmt = $this->pdo->prepare('SELECT * FROM `user` WHERE id = ?');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ? User::fromArray($row) : null;
    }

    public function findByUsername(string $username): ?User
    {
        $stmt = $this->pdo->prepare('SELECT * FROM `user` WHERE username = ?');
        $stmt->execute([$username]);
        $row = $stmt->fetch();
        return $row ? User::fromArray($row) : null;
    }

    public function create(string $username, string $password, ?string $fullName = null, ?string $email = null): User
    {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $this->pdo->prepare('INSERT INTO `user` (username, email, password_hash, full_name) VALUES (?, ?, ?, ?)');
        $stmt->execute([$username, $email, $hash, $fullName]);
        $id = (int)$this->pdo->lastInsertId();
        $u = $this->findById($id);
        // Should not be null; but just in case
        if (!$u) {
            $u = new User();
            $u->id = $id;
            $u->username = $username;
            $u->email = $email;
            $u->passwordHash = $hash;
            $u->fullName = $fullName;
        }
        return $u;
    }

    public function updateProfile(User $user): bool
    {
        $stmt = $this->pdo->prepare(
            'UPDATE `user` SET
                full_name = ?,
                description = ?,
                avatar_url = ?,
                avatar_frame = ?,
                avatar_sticker = ?,
                status_note = ?,
                status_note_expires = ?,
                status_note_color = ?,
                status_note_bg = ?,
                status_note_emoji = ?,
                social_facebook = ?,
                social_instagram = ?,
                social_tiktok = ?,
                social_youtube = ?,
                theme_mode = ?,
                accent_color = ?,
                link_color = ?,
                language = ?,
                timezone = ?,
                pronouns = ?,
                website_url = ?,
                location = ?,
                birthdate = ?,
                birthdate_visibility = ?,
                text_scale = ?,
                compact_mode = ?,
                reduce_motion = ?,
                halo_strength = ?,
                avatar_frame_favs = ?
             WHERE id = ?'
        );
        return $stmt->execute([
            $user->fullName,
            $user->description,
            $user->avatarUrl,
            $user->avatarFrame,
            $user->avatarSticker,
            $user->statusNote,
            $user->statusNoteExpires,
            $user->statusNoteColor,
            $user->statusNoteBg,
            $user->statusNoteEmoji,
            $user->socialFacebook,
            $user->socialInstagram,
            $user->socialTiktok,
            $user->socialYoutube,
            $user->themeMode,
            $user->accentColor,
            $user->linkColor,
            $user->language,
            $user->timezone,
            $user->pronouns,
            $user->websiteUrl,
            $user->location,
            $user->birthdate,
            $user->birthdateVisibility,
            $user->textScale,
            (int)$user->compactMode,
            (int)$user->reduceMotion,
            $user->haloStrength,
            $user->avatarFrameFavs,
            $user->id,
        ]);
    }

    /**
     * Store avatar URL + bytes + mime into DB.
     */
    public function updateAvatarData(int $userId, ?string $avatarUrl, ?string $mime, ?string $bytes): bool
    {
        $stmt = $this->pdo->prepare('UPDATE `user` SET avatar_url = ?, avatar_mime = ?, avatar_blob = ? WHERE id = ?');
        // Use PDO::PARAM_LOB for blob
        return $stmt->execute([$avatarUrl, $mime, $bytes, $userId]);
    }

    /**
     * Clear avatar fields in DB.
     */
    public function clearAvatarData(int $userId): bool
    {
        $stmt = $this->pdo->prepare('UPDATE `user` SET avatar_url = NULL, avatar_mime = NULL, avatar_blob = NULL WHERE id = ?');
        return $stmt->execute([$userId]);
    }

    public function updateBannerUrl(int $userId, ?string $url): bool
    {
        $stmt = $this->pdo->prepare('UPDATE `user` SET banner_url = ? WHERE id = ?');
        return $stmt->execute([$url, $userId]);
    }

    public function clearBannerUrl(int $userId): bool
    {
        $stmt = $this->pdo->prepare('UPDATE `user` SET banner_url = NULL WHERE id = ?');
        return $stmt->execute([$userId]);
    }
}
