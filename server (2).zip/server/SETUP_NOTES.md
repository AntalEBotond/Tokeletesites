## Setup Notes (XAMPP + MySQL on 127.0.0.1:13306)

- API base URL expected by the Flutter app: `http://127.0.0.1/bot/server/public`
  - Endpoints: `/api/login.php`, `/api/profile.php`, `/api/avatar.php`, `/api/register.php`
- Database defaults are set to:
  - Host: `127.0.0.1`
  - Port: `13306`
  - Name: `test`
  - User: `root`
  - Pass: empty
  - File: `server/config/config.php` (can be overridden via env vars `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASS`).

### Schema
- Import `server/schema.sql` into the `test` database.
- Important: Do not seed users with MySQL `PASSWORD()`; PHP uses `password_hash()`/`password_verify()`.
  - Either register via `public/api/register.php`, or insert using a PHP-generated hash.

### Quick curl checks (optional)
1) Login (after you’ve created a user):
   curl -X POST http://127.0.0.1/bot/server/public/api/login.php \
        -H "Content-Type: application/json" \
        -d '{"username":"sysadm","password":"sysadm"}'

2) Get profile:
   curl http://127.0.0.1/bot/server/public/api/profile.php \
        -H "Authorization: Bearer <TOKEN>"

3) Upload avatar:
   curl -X POST http://127.0.0.1/bot/server/public/api/avatar.php \
        -H "Authorization: Bearer <TOKEN>" \
        -F "file=@C:/full/path/to/avatar.jpg"

### Flutter hints
- On Windows or Web, `127.0.0.1` base URL is fine. On Android emulator, use `10.0.2.2` instead of `127.0.0.1`.
- Update `lib/services/api_service.dart` `baseUrl` if your local URL differs.
