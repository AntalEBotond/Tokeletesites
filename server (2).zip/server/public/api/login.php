<?php
require __DIR__ . '/../bootstrap.php';

use App\Core\Response;
use App\Repositories\UserRepository;
use App\Repositories\TokenRepository;
use App\Services\AuthService;

$config = require __DIR__ . '/../../config/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    Response::json(['error' => 'Method Not Allowed'], 405);
}

$body = read_json_body();
$username = trim($body['username'] ?? '');
$password = (string)($body['password'] ?? '');

if ($username === '' || $password === '') {
    Response::json(['error' => 'username and password are required'], 400);
}

$auth = new AuthService(new UserRepository(), new TokenRepository(), $config['auth']['token_ttl'] ?? (7*24*3600));
$result = $auth->login($username, $password);

if (!$result) {
    // do not reveal whether username exists
    Response::json(['error' => 'Invalid credentials'], 401);
}

Response::json([
    'token' => $result['token'],
    'user' => $result['user']->toPublicArray(),
]);

