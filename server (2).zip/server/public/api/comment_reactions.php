<?php
require __DIR__ . '/../bootstrap.php';

use App\Core\Response;
use App\Repositories\UserRepository;
use App\Repositories\TokenRepository;
use App\Services\AuthService;
use App\Core\Database;

$config = require __DIR__ . '/../../config/config.php';
$auth = new AuthService(new UserRepository(), new TokenRepository(), $config['auth']['token_ttl'] ?? (7*24*3600));
$pdo = Database::pdo();

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        $commentId = isset($_GET['comment_id']) ? (int)$_GET['comment_id'] : 0;
        if ($commentId <= 0) Response::json(['error' => 'comment_id required'], 400);
        $stmt = $pdo->prepare('SELECT type, COUNT(*) as cnt FROM comment_reactions WHERE comment_id = ? GROUP BY type');
        $stmt->execute([$commentId]);
        $counts = [];
        foreach ($stmt->fetchAll() ?: [] as $r) { $counts[$r['type']] = (int)$r['cnt']; }
        // whether current user reacted
        $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
        $user = $auth->authenticate($authHeader);
        $userReaction = null;
        if ($user) {
            $s = $pdo->prepare('SELECT type FROM comment_reactions WHERE comment_id=? AND user_id=? LIMIT 1');
            $s->execute([$commentId, $user->id]);
            $row = $s->fetch();
            $userReaction = $row['type'] ?? null;
        }
        Response::json(['counts' => $counts, 'user_reaction' => $userReaction]);
        break;
    case 'POST':
        $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
        if ($authHeader === '' && function_exists('getallheaders')) { $h = getallheaders(); if (isset($h['Authorization'])) $authHeader = $h['Authorization']; }
        $user = $auth->authenticate($authHeader);
        if (!$user) Response::json(['error' => 'Unauthorized'], 401);
        $body = read_json_body();
        $commentId = (int)($body['comment_id'] ?? 0);
        $type = preg_replace('/[^a-z]/', '', strtolower($body['type'] ?? 'like'));
        if ($commentId <= 0) Response::json(['error' => 'comment_id required'], 400);
        // toggle
        $s = $pdo->prepare('SELECT id, type FROM comment_reactions WHERE comment_id=? AND user_id=? LIMIT 1');
        $s->execute([$commentId, $user->id]);
        $row = $s->fetch();
        if ($row) {
            if ($row['type'] === $type) {
                $d = $pdo->prepare('DELETE FROM comment_reactions WHERE id=?');
                $d->execute([(int)$row['id']]);
                Response::json(['reacted' => false]);
            } else {
                $u = $pdo->prepare('UPDATE comment_reactions SET type=? WHERE id=?');
                $u->execute([$type, (int)$row['id']]);
                Response::json(['reacted' => true, 'type' => $type]);
            }
        } else {
            $i = $pdo->prepare('INSERT INTO comment_reactions (comment_id, user_id, type) VALUES (?, ?, ?)');
            $i->execute([$commentId, $user->id, $type]);
            Response::json(['reacted' => true, 'type' => $type]);
        }
        break;
    default:
        Response::json(['error' => 'Method Not Allowed'], 405);
}

