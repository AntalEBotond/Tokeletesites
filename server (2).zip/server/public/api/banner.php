<?php
require __DIR__ . '/../bootstrap.php';

use App\Core\Response;
use App\Repositories\UserRepository;
use App\Repositories\TokenRepository;
use App\Services\AuthService;

$config = require __DIR__ . '/../../config/config.php';
$auth = new AuthService(new UserRepository(), new TokenRepository(), $config['auth']['token_ttl'] ?? (7*24*3600));

$authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
if ($authHeader === '' && function_exists('getallheaders')) {
    $headers = getallheaders();
    if (isset($headers['Authorization'])) {
        $authHeader = $headers['Authorization'];
    }
}
$user = $auth->authenticate($authHeader);
if (!$user) {
    Response::json(['error' => 'Unauthorized'], 401);
}

$publicDir = realpath(__DIR__ . '/..');
$uploadsDir = $publicDir . DIRECTORY_SEPARATOR . 'uploads';
$bannersDir = $uploadsDir . DIRECTORY_SEPARATOR . 'banners';
if (!is_dir($bannersDir)) {
    @mkdir($bannersDir, 0777, true);
}

function absolute_url_banner(string $path): string {
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? ($_SERVER['SERVER_NAME'] ?? 'localhost');
    if ($path && $path[0] !== '/') $path = '/' . $path;
    return $scheme . '://' . $host . $path;
}

// Determine the public URL base corresponding to $publicDir.
$apiDirUrl = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/'), '/');
$publicUrlBase = rtrim(dirname($apiDirUrl), '/');

function allowed_banner_ext(string $mime): ?string {
    static $map = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
        'image/gif'  => 'gif',
    ];
    return $map[$mime] ?? null;
}

switch ($_SERVER['REQUEST_METHOD']) {
    case 'POST':
        if (!isset($_FILES['file'])) {
            Response::json(['error' => 'No file uploaded'], 400);
        }
        $file = $_FILES['file'];
        if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
            Response::json(['error' => 'Upload error'], 400);
        }
        if (($file['size'] ?? 0) <= 0 || $file['size'] > 8 * 1024 * 1024) {
            Response::json(['error' => 'Invalid file size'], 400);
        }
        $tmpName = $file['tmp_name'];
        $mime = null;
        if (class_exists('finfo')) {
            $finfo = new \finfo(FILEINFO_MIME_TYPE);
            $mime = $finfo->file($tmpName) ?: null;
        }
        $ext = $mime ? allowed_banner_ext($mime) : null;
        if (!$ext) {
            $name = $file['name'] ?? '';
            $extGuess = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            $whitelist = ['jpg','jpeg','png','webp','gif'];
            if (in_array($extGuess, $whitelist, true)) {
                $ext = $extGuess === 'jpeg' ? 'jpg' : $extGuess;
            }
        }
        if (!$ext) {
            Response::json(['error' => 'Unsupported file type'], 415);
        }
        $safeName = 'u' . $user->id . '_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        $targetPath = $bannersDir . DIRECTORY_SEPARATOR . $safeName;
        if (!move_uploaded_file($tmpName, $targetPath)) {
            Response::json(['error' => 'Failed to save file'], 500);
        }

        // Remove old banner if exists and under uploads/banners
        $old = $user->bannerUrl ?? null;
        if ($old) {
            $parsed = parse_url($old);
            $oldPath = $parsed['path'] ?? $old;
            $localPath = null;
            if (strpos($oldPath, $publicUrlBase . '/uploads/') === 0) {
                $rel = substr($oldPath, strlen($publicUrlBase));
                $localPath = realpath($publicDir . $rel);
            } elseif (strpos($oldPath, '/uploads/') === 0) {
                $localPath = realpath($publicDir . $oldPath);
            }
            if ($localPath && strpos($localPath, realpath($bannersDir)) === 0 && file_exists($localPath)) {
                @unlink($localPath);
            }
        }

        $relative = $publicUrlBase . '/uploads/banners/' . $safeName;
        $newUrl = absolute_url_banner($relative);
        (new UserRepository())->updateBannerUrl($user->id, $newUrl);

        Response::json(['banner_url' => $newUrl]);
        break;

    case 'DELETE':
        $repo = new UserRepository();
        // Need fresh banner value from DB in case $user->bannerUrl not loaded
        $dbUser = $repo->findById($user->id);
        $old = $dbUser ? ($dbUser->bannerUrl ?? null) : ($user->bannerUrl ?? null);
        if ($old) {
            $parsed = parse_url($old);
            $oldPath = $parsed['path'] ?? $old;
            $localPath = null;
            if (strpos($oldPath, $publicUrlBase . '/uploads/') === 0) {
                $rel = substr($oldPath, strlen($publicUrlBase));
                $localPath = realpath($publicDir . $rel);
            } elseif (strpos($oldPath, '/uploads/') === 0) {
                $localPath = realpath($publicDir . $oldPath);
            }
            if ($localPath && strpos($localPath, realpath($bannersDir)) === 0 && file_exists($localPath)) {
                @unlink($localPath);
            }
        }
        $repo->clearBannerUrl($user->id);
        Response::json(['ok' => true]);
        break;

    default:
        Response::json(['error' => 'Method Not Allowed'], 405);
}

