import 'dart:async'; // ===== 2025 UPGRADE: ütemezés, debounce
import 'dart:convert'; // ===== 2025 UPGRADE: export/import
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'api_service.dart';

/// ===== 2025 UPGRADE: új beállítási politika az egyszerű ThemeMode fölé
enum ThemePreference { system, light, dark, scheduled }

class SettingsController extends ChangeNotifier {
  SettingsController._();
  static final SettingsController instance = SettingsController._();

  // ---- Alap beállítások (visszafelé kompatibilis) ----
  ThemePreference _themePref = ThemePreference.system; // 'system' | 'light' | 'dark' | 'scheduled'
  ThemeMode _manualThemeMode = ThemeMode.system; // ha _themePref != scheduled, ez számít
  Locale? _locale; // null => rendszer

  // ---- 2025 extra beállítások ----
  // Dinamikus/seed színezés
  bool _useDynamicColor = true; // Android 12+ Material You színek
  int? _seedArgb; // saját seed-szín (null => alap/dinamikus)
  // Különleges megjelenítés
  bool _trueBlack = false; // AMOLED fekete
  bool _highContrast = false; // nagy kontraszt
  double _textScale = 1.0; // 0.85..1.30
  bool _reduceMotion = false; // animációk csökkentése
  bool _haptics = true; // haptikus visszajelzés engedélyezése

  // Ütemezett téma (pl. 20:00 – 06:00 sötét)
  int _schedStartMin = 20 * 60; // percben 0..1439
  int _schedEndMin = 6 * 60;
  Timer? _scheduleTicker;

  // Debounce-olt profil szinkron
  Timer? _syncDebounce;
  Map<String, dynamic> _pendingPayload = {};

  // ---------------- GETTEREK ----------------
  ThemePreference get themePreference => _themePref;
  ThemeMode get themeMode => _manualThemeMode; // manuális (vagy system) beállítás
  Locale? get locale => _locale;

  /// ===== 2025 UPGRADE:
  /// A MaterialApp-hoz ***EZT*** add át: controller.effectiveThemeMode
  ThemeMode get effectiveThemeMode {
    if (_themePref != ThemePreference.scheduled) {
      return _manualThemeMode;
    }
    return _isDarkNow() ? ThemeMode.dark : ThemeMode.light;
  }

  bool get useDynamicColor => _useDynamicColor;
  Color? get seedColor => _seedArgb == null ? null : Color(_seedArgb!);
  bool get trueBlack => _trueBlack;
  bool get highContrast => _highContrast;
  double get textScale => _textScale;
  bool get reduceMotion => _reduceMotion;
  bool get haptics => _haptics;

  TimeOfDay get scheduledStart =>
      TimeOfDay(hour: _schedStartMin ~/ 60, minute: _schedStartMin % 60);
  TimeOfDay get scheduledEnd =>
      TimeOfDay(hour: _schedEndMin ~/ 60, minute: _schedEndMin % 60);

  // ---------------- INIT / LOAD ----------------
  Future<void> load() async {
    final sp = await SharedPreferences.getInstance();

    // Visszafelé kompatibilis olvasás
    final tm = sp.getString('profile_theme_mode') ?? 'system';
    _manualThemeMode = _parseThemeMode(tm);

    // ===== 2025 UPGRADE: új theme preference (ütemezéshez)
    _themePref = _parseThemePreference(
      sp.getString('profile_theme_pref') ?? _themePrefToString(_themePref),
    );

    // Nyelv (teljes language tag támogatás)
    final langTag = sp.getString('profile_language_tag');
    if (langTag != null && langTag.isNotEmpty) {
      _locale = _parseLocaleTag(langTag);
    } else {
      // Régi kulcs támogatás
      final lang = sp.getString('profile_language');
      _locale = (lang != null && lang.isNotEmpty) ? Locale(lang) : null;
    }

    // ===== 2025 extra opciók
    _useDynamicColor = sp.getBool('ui_use_dynamic_color') ?? _useDynamicColor;
    _seedArgb = sp.getInt('ui_seed_color_argb');
    _trueBlack = sp.getBool('ui_true_black') ?? _trueBlack;
    _highContrast = sp.getBool('ui_high_contrast') ?? _highContrast;
    _textScale = (sp.getDouble('ui_text_scale') ?? _textScale).clamp(0.85, 1.30);
    _reduceMotion = sp.getBool('ui_reduce_motion') ?? _reduceMotion;
    _haptics = sp.getBool('ui_haptics') ?? _haptics;

    _schedStartMin = sp.getInt('theme_sched_start_min') ?? _schedStartMin;
    _schedEndMin = sp.getInt('theme_sched_end_min') ?? _schedEndMin;

    _restartScheduleTickerIfNeeded();

    notifyListeners();
  }

  // ---------------- SETTEREK + MENTÉS + SYNC ----------------

  /// Gyors váltó: system → dark → light → system...
  void quickToggleTheme() {
    switch (_themePref) {
      case ThemePreference.system:
        setThemePreference(ThemePreference.dark);
        break;
      case ThemePreference.dark:
        setThemePreference(ThemePreference.light);
        break;
      case ThemePreference.light:
      case ThemePreference.scheduled:
        setThemePreference(ThemePreference.system);
        break;
    }
  }

  Future<void> setThemePreference(ThemePreference pref) async {
    if (_themePref == pref) return;
    _themePref = pref;
    final sp = await SharedPreferences.getInstance();
    await sp.setString('profile_theme_pref', _themePrefToString(pref));
    _restartScheduleTickerIfNeeded();
    _debouncedSync({'theme_pref': _themePrefToString(pref)});
    notifyListeners();
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    // Manuális ThemeMode (ha nem ütemezett)
    if (_manualThemeMode == mode) return;
    _manualThemeMode = mode;
    final sp = await SharedPreferences.getInstance();
    await sp.setString('profile_theme_mode', _themeToString(mode));
    _debouncedSync({'theme_mode': _themeToString(mode)});
    notifyListeners();
  }

  Future<void> setLocale(Locale? locale) async {
    final prev = _locale?.toLanguageTag();
    final next = locale?.toLanguageTag();
    if (prev == next) return;
    _locale = locale;
    final sp = await SharedPreferences.getInstance();
    if (next == null || next.isEmpty) {
      await sp.remove('profile_language_tag');
      // régi kulcs tisztítás
      await sp.remove('profile_language');
    } else {
      await sp.setString('profile_language_tag', next);
      await sp.setString('profile_language', locale!.languageCode);
    }
    _debouncedSync({'language_tag': next});
    notifyListeners();
  }

  Future<void> setUseDynamicColor(bool v) async {
    if (_useDynamicColor == v) return;
    _useDynamicColor = v;
    final sp = await SharedPreferences.getInstance();
    await sp.setBool('ui_use_dynamic_color', v);
    _debouncedSync({'use_dynamic_color': v});
    notifyListeners();
  }

  Future<void> setSeedColor(Color? color) async {
    final argb = color?.value;
    if (_seedArgb == argb) return;
    _seedArgb = argb;
    final sp = await SharedPreferences.getInstance();
    if (argb == null) {
      await sp.remove('ui_seed_color_argb');
    } else {
      await sp.setInt('ui_seed_color_argb', argb);
    }
    _debouncedSync({'seed_color_argb': argb});
    notifyListeners();
  }

  Future<void> setTrueBlack(bool v) async {
    if (_trueBlack == v) return;
    _trueBlack = v;
    final sp = await SharedPreferences.getInstance();
    await sp.setBool('ui_true_black', v);
    _debouncedSync({'true_black': v});
    notifyListeners();
  }

  Future<void> setHighContrast(bool v) async {
    if (_highContrast == v) return;
    _highContrast = v;
    final sp = await SharedPreferences.getInstance();
    await sp.setBool('ui_high_contrast', v);
    _debouncedSync({'high_contrast': v});
    notifyListeners();
  }

  Future<void> setTextScale(double v) async {
    final nv = v.clamp(0.85, 1.30);
    if (_textScale == nv) return;
    _textScale = nv;
    final sp = await SharedPreferences.getInstance();
    await sp.setDouble('ui_text_scale', _textScale);
    _debouncedSync({'text_scale': _textScale});
    notifyListeners();
  }

  Future<void> setReduceMotion(bool v) async {
    if (_reduceMotion == v) return;
    _reduceMotion = v;
    final sp = await SharedPreferences.getInstance();
    await sp.setBool('ui_reduce_motion', v);
    _debouncedSync({'reduce_motion': v});
    notifyListeners();
  }

  Future<void> setHaptics(bool v) async {
    if (_haptics == v) return;
    _haptics = v;
    final sp = await SharedPreferences.getInstance();
    await sp.setBool('ui_haptics', v);
    _debouncedSync({'haptics': v});
    notifyListeners();
  }

  /// Ütemezett sötét mód időablak beállítása (helyi idő szerint)
  Future<void> setThemeSchedule({
    required TimeOfDay start,
    required TimeOfDay end,
  }) async {
    final s = start.hour * 60 + start.minute;
    final e = end.hour * 60 + end.minute;
    if (_schedStartMin == s && _schedEndMin == e) return;

    _schedStartMin = s;
    _schedEndMin = e;

    final sp = await SharedPreferences.getInstance();
    await sp.setInt('theme_sched_start_min', _schedStartMin);
    await sp.setInt('theme_sched_end_min', _schedEndMin);

    _debouncedSync({
      'theme_schedule': {'start_min': _schedStartMin, 'end_min': _schedEndMin}
    });

    _restartScheduleTickerIfNeeded();
    notifyListeners();
  }

  // ---------------- EXPORT / IMPORT / RESET ----------------

  /// Exportálja az összes beállítást JSON-ként (UI-ból elmentheted fájlba)
  Future<String> exportSettingsJson() async {
    final map = <String, dynamic>{
      'theme_pref': _themePrefToString(_themePref),
      'theme_mode': _themeToString(_manualThemeMode),
      'language_tag': _locale?.toLanguageTag(),
      'use_dynamic_color': _useDynamicColor,
      'seed_color_argb': _seedArgb,
      'true_black': _trueBlack,
      'high_contrast': _highContrast,
      'text_scale': _textScale,
      'reduce_motion': _reduceMotion,
      'haptics': _haptics,
      'theme_sched_start_min': _schedStartMin,
      'theme_sched_end_min': _schedEndMin,
    };
    return const JsonEncoder.withIndent('  ').convert(map);
  }

  /// Importálás JSON-ből (érvényes kulcsok felülírják a jelenlegi beállításokat)
  Future<void> importSettingsJson(String jsonStr) async {
    final data = jsonDecode(jsonStr);
    if (data is! Map<String, dynamic>) return;

    final sp = await SharedPreferences.getInstance();

    if (data['theme_pref'] is String) {
      _themePref = _parseThemePreference(data['theme_pref']);
      await sp.setString('profile_theme_pref', data['theme_pref']);
    }
    if (data['theme_mode'] is String) {
      _manualThemeMode = _parseThemeMode(data['theme_mode']);
      await sp.setString('profile_theme_mode', data['theme_mode']);
    }
    if (data['language_tag'] is String?) {
      final tag = data['language_tag'] as String?;
      _locale = (tag == null || tag.isEmpty) ? null : _parseLocaleTag(tag);
      if (tag == null || tag.isEmpty) {
        await sp.remove('profile_language_tag');
        await sp.remove('profile_language');
      } else {
        await sp.setString('profile_language_tag', tag);
        await sp.setString('profile_language', _locale!.languageCode);
      }
    }
    if (data['use_dynamic_color'] is bool) {
      _useDynamicColor = data['use_dynamic_color'];
      await sp.setBool('ui_use_dynamic_color', _useDynamicColor);
    }
    if (data['seed_color_argb'] is int?) {
      _seedArgb = data['seed_color_argb'];
      if (_seedArgb == null) {
        await sp.remove('ui_seed_color_argb');
      } else {
        await sp.setInt('ui_seed_color_argb', _seedArgb!);
      }
    }
    if (data['true_black'] is bool) {
      _trueBlack = data['true_black'];
      await sp.setBool('ui_true_black', _trueBlack);
    }
    if (data['high_contrast'] is bool) {
      _highContrast = data['high_contrast'];
      await sp.setBool('ui_high_contrast', _highContrast);
    }
    if (data['text_scale'] is num) {
      _textScale = (data['text_scale'] as num).toDouble().clamp(0.85, 1.30);
      await sp.setDouble('ui_text_scale', _textScale);
    }
    if (data['reduce_motion'] is bool) {
      _reduceMotion = data['reduce_motion'];
      await sp.setBool('ui_reduce_motion', _reduceMotion);
    }
    if (data['haptics'] is bool) {
      _haptics = data['haptics'];
      await sp.setBool('ui_haptics', _haptics);
    }
    if (data['theme_sched_start_min'] is int) {
      _schedStartMin = data['theme_sched_start_min'];
      await sp.setInt('theme_sched_start_min', _schedStartMin);
    }
    if (data['theme_sched_end_min'] is int) {
      _schedEndMin = data['theme_sched_end_min'];
      await sp.setInt('theme_sched_end_min', _schedEndMin);
    }

    _restartScheduleTickerIfNeeded();
    notifyListeners();
  }

  /// Teljes visszaállítás (lokális tároló törlés + memóriában alapértékek)
  Future<void> resetToDefaults() async {
    final sp = await SharedPreferences.getInstance();
    await sp.remove('profile_theme_pref');
    await sp.remove('profile_theme_mode');
    await sp.remove('profile_language_tag');
    await sp.remove('profile_language');
    await sp.remove('ui_use_dynamic_color');
    await sp.remove('ui_seed_color_argb');
    await sp.remove('ui_true_black');
    await sp.remove('ui_high_contrast');
    await sp.remove('ui_text_scale');
    await sp.remove('ui_reduce_motion');
    await sp.remove('ui_haptics');
    await sp.remove('theme_sched_start_min');
    await sp.remove('theme_sched_end_min');

    _themePref = ThemePreference.system;
    _manualThemeMode = ThemeMode.system;
    _locale = null;
    _useDynamicColor = true;
    _seedArgb = null;
    _trueBlack = false;
    _highContrast = false;
    _textScale = 1.0;
    _reduceMotion = false;
    _haptics = true;
    _schedStartMin = 20 * 60;
    _schedEndMin = 6 * 60;
    _restartScheduleTickerIfNeeded();
    _pendingPayload.clear();

    _debouncedSync({'reset': true});
    notifyListeners();
  }

  // ---------------- BELSŐ LOGIKA ----------------

  void _restartScheduleTickerIfNeeded() {
    _scheduleTicker?.cancel();
    if (_themePref != ThemePreference.scheduled) return;
    // Átállítjuk úgy, hogy a következő határidőben (start vagy end) fusson le
    final now = DateTime.now();
    final msUntil = _millisUntilNextBoundary(now);
    _scheduleTicker = Timer(Duration(milliseconds: msUntil), () {
      // határon átléptünk → új effectiveThemeMode
      notifyListeners();
      // és ütemezzük a következő váltást
      _restartScheduleTickerIfNeeded();
    });
  }

  bool _isDarkNow() {
    final now = DateTime.now();
    final m = now.hour * 60 + now.minute;
    // Kezdés és befejezés átlapolhat éjfélen: pl. 20:00 → 06:00
    if (_schedStartMin <= _schedEndMin) {
      // pl. 08:00 → 18:00 (nappali sötét, ritkább)
      return m >= _schedStartMin && m < _schedEndMin;
    } else {
      // pl. 20:00 → 06:00 (éjszakai sötét, tipikus)
      return m >= _schedStartMin || m < _schedEndMin;
    }
  }

  int _millisUntilNextBoundary(DateTime now) {
    final m = now.hour * 60 + now.minute;
    int nextMin;
    // következő váltás a közelebbi határpont
    final deltas = <int>[
      _deltaForwardMinutes(m, _schedStartMin),
      _deltaForwardMinutes(m, _schedEndMin),
    ];
    nextMin = deltas.reduce((a, b) => a < b ? a : b);
    // a percre igazítunk + másodperc/ezredmásodperc korrekció
    final next = now.add(Duration(minutes: nextMin));
    final aligned = DateTime(
      next.year,
      next.month,
      next.day,
      next.hour,
      next.minute,
    );
    return aligned.difference(now).inMilliseconds.clamp(500, 24 * 60 * 60 * 1000);
  }

  int _deltaForwardMinutes(int fromMin, int toMin) {
    if (toMin >= fromMin) return toMin - fromMin;
    return 1440 - (fromMin - toMin);
  }

  void _debouncedSync(Map<String, dynamic> payload) {
    // ===== 2025 UPGRADE: kíméletes, összevont szinkron
    _pendingPayload.addAll(payload);
    _syncDebounce?.cancel();
    _syncDebounce = Timer(const Duration(seconds: 2), () {
      _syncProfile(_pendingPayload);
      _pendingPayload = {};
    });
  }

  Future<void> _syncProfile(Map<String, dynamic> payload) async {
    try {
      final sp = await SharedPreferences.getInstance();
      final token = sp.getString('auth_token');
      if (token == null) return;
      await ApiService().updateProfile(token, payload);
    } catch (_) {
      // Best-effort; offline stb. → majd legközelebb
    }
  }

  // ---------------- SEGÉDFÜGGVÉNYEK ----------------

  ThemeMode _parseThemeMode(String v) {
    switch (v) {
      case 'light':
        return ThemeMode.light;
      case 'dark':
        return ThemeMode.dark;
      default:
        return ThemeMode.system;
    }
  }

  String _themeToString(ThemeMode m) {
    switch (m) {
      case ThemeMode.light:
        return 'light';
      case ThemeMode.dark:
        return 'dark';
      case ThemeMode.system:
      default:
        return 'system';
    }
  }

  ThemePreference _parseThemePreference(String v) {
    switch (v) {
      case 'light':
        return ThemePreference.light;
      case 'dark':
        return ThemePreference.dark;
      case 'scheduled':
        return ThemePreference.scheduled;
      case 'system':
      default:
        return ThemePreference.system;
    }
  }

  String _themePrefToString(ThemePreference p) {
    switch (p) {
      case ThemePreference.light:
        return 'light';
      case ThemePreference.dark:
        return 'dark';
      case ThemePreference.scheduled:
        return 'scheduled';
      case ThemePreference.system:
      default:
        return 'system';
    }
  }

  Locale _parseLocaleTag(String tag) {
    // Egyszerű parser: "ro", "ro-RO", "en-US" stb.
    final parts = tag.split(RegExp('[-_]'));
    if (parts.length == 1) return Locale(parts[0]);
    if (parts.length == 2) return Locale(parts[0], parts[1]);
    // ha script is lenne (pl. zh-Hant-TW), a 3. elemet ignoráljuk itt
    return Locale(parts[0], parts[1]);
  }
}
