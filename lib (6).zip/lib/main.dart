import 'package:flutter/material.dart';
import '/bejel.dart';
import '/menu.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'services/api_service.dart';
import 'services/settings_service.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await _ensureBaseUrlConsistency();
  await SettingsController.instance.load();
  runApp(const MyApp());
}

Future<void> _ensureBaseUrlConsistency() async {
  final sp = await SharedPreferences.getInstance();
  final current = ApiService.baseUrl;
  final stored = sp.getString('api_base_url');
  if (stored == null || stored != current) {
    // Base URL changed (e.g., switched from 127.0.0.1 to 192.168.x.x) → clear stale auth
    await sp.remove('auth_token');
    await sp.setString('api_base_url', current);
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final seed = const Color(0xFF00C853);
    const emojiFallback = <String>[
      'Noto Color Emoji',
      'Noto Emoji',
      'Segoe UI Emoji',
      'Apple Color Emoji',
      'EmojiOne Color',
      'Twemoji Mozilla',
    ];

    TextTheme withFallback(TextTheme base) => base.copyWith(
          displayLarge: base.displayLarge?.copyWith(fontFamilyFallback: emojiFallback),
          displayMedium: base.displayMedium?.copyWith(fontFamilyFallback: emojiFallback),
          displaySmall: base.displaySmall?.copyWith(fontFamilyFallback: emojiFallback),
          headlineLarge: base.headlineLarge?.copyWith(fontFamilyFallback: emojiFallback),
          headlineMedium: base.headlineMedium?.copyWith(fontFamilyFallback: emojiFallback),
          headlineSmall: base.headlineSmall?.copyWith(fontFamilyFallback: emojiFallback),
          titleLarge: base.titleLarge?.copyWith(fontFamilyFallback: emojiFallback),
          titleMedium: base.titleMedium?.copyWith(fontFamilyFallback: emojiFallback),
          titleSmall: base.titleSmall?.copyWith(fontFamilyFallback: emojiFallback),
          bodyLarge: base.bodyLarge?.copyWith(fontFamilyFallback: emojiFallback),
          bodyMedium: base.bodyMedium?.copyWith(fontFamilyFallback: emojiFallback),
          bodySmall: base.bodySmall?.copyWith(fontFamilyFallback: emojiFallback),
          labelLarge: base.labelLarge?.copyWith(fontFamilyFallback: emojiFallback),
          labelMedium: base.labelMedium?.copyWith(fontFamilyFallback: emojiFallback),
          labelSmall: base.labelSmall?.copyWith(fontFamilyFallback: emojiFallback),
        );
    final controller = SettingsController.instance;
    final light = ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.light),
      useMaterial3: true,
      brightness: Brightness.light,
      textTheme: withFallback(ThemeData(brightness: Brightness.light).textTheme),
      primaryTextTheme: withFallback(ThemeData(brightness: Brightness.light).primaryTextTheme),
    );
    final dark = ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.dark),
      useMaterial3: true,
      brightness: Brightness.dark,
      textTheme: withFallback(ThemeData(brightness: Brightness.dark).textTheme),
      primaryTextTheme: withFallback(ThemeData(brightness: Brightness.dark).primaryTextTheme),
    );
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        return MaterialApp(
          title: 'Proiect Flutter',
          debugShowCheckedModeBanner: false,
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          supportedLocales: const [Locale('hu'), Locale('en'), Locale('ro')],
          locale: controller.locale,
          theme: light,
          darkTheme: dark,
          themeMode: controller.themeMode,
          initialRoute: '/login',
          routes: {
            '/login': (_) => const BejelentkezesPage(),
            '/menu': (_) => const MenuScreen(),
          },
        );
      },
    );
  }
}
